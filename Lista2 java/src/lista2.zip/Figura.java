public abstract class Figura implements Deklaracje {
}
