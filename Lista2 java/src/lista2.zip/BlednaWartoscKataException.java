public class BlednaWartoscKataException extends Exception{
	public BlednaWartoscKataException(String error) {
		super(error);
	}
}
