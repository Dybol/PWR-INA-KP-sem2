public interface Deklaracje {
	double pole();
	double obwod();

	}
